## How to run

- compile with g++ `g++ *.cpp -o out`
- in the folder that the `interpreter.cpp` is, it must have a sub-folder "tests" where the program you want to interpret must be.
- tu run, execute the cmd: `./out <FILENAME.bf>`

### File Tree example

`./out test.bf`

-.
-interpreter.cpp
-tests/
--test.bf
